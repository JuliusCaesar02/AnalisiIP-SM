//Giorgiutti "JuliusCaesar02" Cristian	
//Programma analisi indirizzo IP / Subnet mask
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		Sub sub = new Sub();
		System.out.println("Inserire indirizzo ip (formato 000.000.000.000): ");											//Rileva in input l'IP come stringa
		String ip = scanner.next();
		sub.setIp (ip);																										//Salva la variabile ip nella class Analisi
		sub.decon(sub.setIp(ip));																							//Separa la stringa in un'array intero con una posizione per byte
	    sub.setClasse();																									//Salva la classe come variabile char e la da in output
	    if(sub.setClasse() == 'X') {																						//Se il modulo da in output X allora la classe non esiste
	    	System.out.println("ERRORE! La classe � inesistente");		
	    	System.exit(0);
	    }
	    else if(sub.setClasse() == 'D' || sub.setClasse() == 'E') {															//Se il metodo da in output D o E allora il programma � concluso
	    	System.out.println("1- La classe � " +sub.setClasse());	
	    	System.out.println("Non � possibile eseguire altre operazioni su IP di classe " +sub.setClasse());
	    	System.exit(0);
	    }
		System.out.println("Inserire subnetmask (formato 000.000.000.000): ");												//Rileva in input la SM come stringa
		String sm = scanner.next();													
		sub.setSm (sm);																										//Salva la variabile SM nella class Analisi
	    sub.decon(sub.setIp(sm));																							//Separa la stringa in un'array intero con una posizione per byte
	    //sub.getByte(sub.decon((sub.setIp(ip))));																			//Stampa l'array IP posizione per posizione (byte per byte) per fini di debug
	    sub.setBinaryBit(sub.decon(sub.setIp(ip)));																			//Importa int[] contenente i 4 byte dell'ip (deconIp) e li trasforma in stringa binaria
	    System.out.println("IP bit " +sub.getBinaryBit(sub.decon((sub.setIp(ip)))));										//Importa String (setBinaryBit(deconIp)) e la stampa
	    //sub.getByte(sub.decon((sub.setIp(sm))));																			//Stampa l'array SM posizione per posizione (byte per byte) per fini di debug
	    sub.setBinaryBit(sub.decon((sub.setIp(sm))));																		//Importa int[] contenente i 4 byte dell'sm (deconSm) e li trasforma in stringa binaria
	    System.out.println("SM bit " +sub.getBinaryBit(sub.decon((sub.setIp(sm)))));										//Importa String (setBinaryBit(deconSm)) e la stampa
	    sub.decon((sub.setIp(ip)));	
	    System.out.println("1- La classe � " +sub.setClasse());																//1 Ritorna la classe come char dopo degli if
	    sub.setByteCrit();																									//2 Partendo dall'ultima posizione controlla se esiste un byte critico
	    sub.getByteCrit();															
	    System.out.println("3- Il CIDR � /" +sub.setCidr());																//3 Conta per ogni byte con Integer.bitCount i bit a 1 e li somma
	    System.out.println("4- I bit di rete sono " +sub.setNetBit());														//4 Prendendo la classe, stampa i netbit con un semplice switch case
	    sub.setSubBit();																									//5 subbit = cidr - netbit
	    sub.getSubBit();																									//Verifica che i subbit siano un numero >= 0
	    sub.setHostBit();																									//6 hostbit = 32 - netbit - subbit
	    sub.getHostBit();																									//Verifica che gli hostbit siano un numero > 0    															
	    System.out.println("7- Ci possono essere " +sub.setHostESubPerNet(sub.setHostBit(), 2) +" host in ogni subnet (" +(sub.setHostESubPerNet(sub.setHostBit(), 0)) +")");	//7 host per sub = (Math.pow(2,hostBit))-2
	    System.out.println("8- Ci possono essere " +sub.setHostESubPerNet(sub.setSubBit(), 0) +" subnet nella rete");								//8 sub nella rete = Math.pow(2,subBit)													
	    System.out.println("9- Il magic number � " +sub.setMn());															//9 magic number = 256 - byte della subnet mask[byte critico]
	    sub.setNetIp();																										//10 and bitwise tra ogni byte della sm e dell'ip
	    //sub.getByte(sub.setNetIp());																						//Stampa l'array NetIp posizione per posizione (byte per byte) per fini di debug
	    sub.getNetIp();																										//Stampa il NetIp come stringa   netIpStringa = Arrays.toString(netIpByte); 
	    sub.setBroadIp();																									//11 complemento bitwise per ogni byte della subnet, or bitwise tra ogni byte complementoSubMask e IP
	    //sub.getByte(sub.setBroadIp());																					//Stampa l'array SubnetIp posizione per posizione (byte per byte) per fini di debug
	    sub.getBroadIp();																									//Stampa il SubnetIp come stringa   subnetIpStringa = Arrays.toString(subnetIpByte); 																								//12 Aumenta di 1 l'ultimo byte del netIP																									//Diminuisce di 1 l'ultimo byte del subnetIP
	    sub.getRange();																										//Stampa primo e ultimo host come stringa
	    System.out.println("13- L'IP fa parte della subnet " +sub.setSubNet());												//13- Tronca String contenente l'Ip in binario (setBinaryBit(deconIp)) mantenendo solo SubnetBit, ritrasformandolo poi in decimale
	    sub.setBitMap();																									//Stampa un grafico con dei cicli for in base ai bit di rete, di subnet e di host
		scanner.close();
	}
}
